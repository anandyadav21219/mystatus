-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 03, 2019 at 04:11 PM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 7.1.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mystatus_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `categorytbl`
--

CREATE TABLE `categorytbl` (
  `categoryid` int(11) NOT NULL,
  `languageid` int(11) NOT NULL,
  `categoryname` varchar(255) NOT NULL,
  `category_img` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `languagetbl`
--

CREATE TABLE `languagetbl` (
  `languageid` int(11) NOT NULL,
  `languagename` varchar(255) NOT NULL,
  `Language_img` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `posttbl`
--

CREATE TABLE `posttbl` (
  `postid` int(11) NOT NULL,
  `categoryid` int(11) NOT NULL,
  `languageid` int(11) NOT NULL,
  `thumbnail_img` text NOT NULL,
  `title` varchar(255) NOT NULL,
  `postpath` text NOT NULL,
  `no_of_like` int(11) NOT NULL,
  `no_of_share` int(11) NOT NULL,
  `no_of_download` int(11) NOT NULL,
  `no_of_view` int(11) NOT NULL,
  `post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `posttbl_img`
--

CREATE TABLE `posttbl_img` (
  `postid` int(11) NOT NULL,
  `categoryid` int(11) NOT NULL,
  `languageid` int(11) NOT NULL,
  `thumbnail_img` text NOT NULL,
  `title` varchar(255) NOT NULL,
  `postpath` text NOT NULL,
  `no_of_like` int(11) NOT NULL,
  `no_of_share` int(11) NOT NULL,
  `no_of_download` int(11) NOT NULL,
  `no_of_view` int(11) NOT NULL,
  `post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categorytbl`
--
ALTER TABLE `categorytbl`
  ADD PRIMARY KEY (`categoryid`),
  ADD KEY `languageid` (`languageid`);

--
-- Indexes for table `languagetbl`
--
ALTER TABLE `languagetbl`
  ADD PRIMARY KEY (`languageid`);

--
-- Indexes for table `posttbl`
--
ALTER TABLE `posttbl`
  ADD PRIMARY KEY (`postid`),
  ADD KEY `languageid` (`languageid`),
  ADD KEY `categoryid` (`categoryid`);

--
-- Indexes for table `posttbl_img`
--
ALTER TABLE `posttbl_img`
  ADD PRIMARY KEY (`postid`),
  ADD KEY `languageid` (`languageid`),
  ADD KEY `categoryid` (`categoryid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categorytbl`
--
ALTER TABLE `categorytbl`
  MODIFY `categoryid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `languagetbl`
--
ALTER TABLE `languagetbl`
  MODIFY `languageid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `posttbl`
--
ALTER TABLE `posttbl`
  MODIFY `postid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `posttbl_img`
--
ALTER TABLE `posttbl_img`
  MODIFY `postid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `categorytbl`
--
ALTER TABLE `categorytbl`
  ADD CONSTRAINT `categorytbl_ibfk_1` FOREIGN KEY (`languageid`) REFERENCES `languagetbl` (`languageid`);

--
-- Constraints for table `posttbl`
--
ALTER TABLE `posttbl`
  ADD CONSTRAINT `posttbl_ibfk_1` FOREIGN KEY (`languageid`) REFERENCES `languagetbl` (`languageid`),
  ADD CONSTRAINT `posttbl_ibfk_2` FOREIGN KEY (`categoryid`) REFERENCES `categorytbl` (`categoryid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
