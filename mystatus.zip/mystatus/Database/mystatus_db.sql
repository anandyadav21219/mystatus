-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 29, 2019 at 01:41 PM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 7.1.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mystatus_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `categorytbl`
--

CREATE TABLE `categorytbl` (
  `categoryid` int(11) NOT NULL,
  `languageid` int(11) NOT NULL,
  `categoryname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categorytbl`
--

INSERT INTO `categorytbl` (`categoryid`, `languageid`, `categoryname`) VALUES
(1, 1, 'Love'),
(2, 1, 'Book'),
(5, 1, 'Love-Gujarati'),
(6, 1, 'Love-Gujarati'),
(7, 2, 'Love-Gujarati');

-- --------------------------------------------------------

--
-- Table structure for table `languagetbl`
--

CREATE TABLE `languagetbl` (
  `languageid` int(11) NOT NULL,
  `languagename` varchar(255) NOT NULL,
  `Language_img` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `languagetbl`
--

INSERT INTO `languagetbl` (`languageid`, `languagename`, `Language_img`) VALUES
(1, 'English', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQzMVxYMqiUIazSN61SvQ8r68M-NWknH9x45rVbDxKANDif2E-V5g'),
(2, 'Hindi', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQzMVxYMqiUIazSN61SvQ8r68M-NWknH9x45rVbDxKANDif2E-V5g');

-- --------------------------------------------------------

--
-- Table structure for table `posttbl`
--

CREATE TABLE `posttbl` (
  `postid` int(11) NOT NULL,
  `categoryid` int(11) NOT NULL,
  `languageid` int(11) NOT NULL,
  `thumbnail_img` text NOT NULL,
  `title` varchar(255) NOT NULL,
  `postpath` text NOT NULL,
  `no_of_like` int(11) NOT NULL,
  `no_of_share` int(11) NOT NULL,
  `no_of_download` int(11) NOT NULL,
  `no_of_view` int(11) NOT NULL,
  `post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posttbl`
--

INSERT INTO `posttbl` (`postid`, `categoryid`, `languageid`, `thumbnail_img`, `title`, `postpath`, `no_of_like`, `no_of_share`, `no_of_download`, `no_of_view`, `post_date`) VALUES
(12, 1, 1, '', 'Android  App & Game  Developer', 'Screenshot (27).png', 1, 1, 1, 3, '2019-09-29 10:57:11'),
(13, 2, 2, '', 'Android  App & Game  Developer', 'Screenshot (16).png', 1, 1, 1, 1, '2019-09-28 09:11:32'),
(14, 1, 1, 'Screenshot (26).png', 'Android  App & Game  Developer', 'Screenshot (27).png', 11, 1, 1, 1, '2019-09-29 07:41:45'),
(15, 1, 1, 'Screenshot (27).png', 'Android  App & Game  Developer', 'Screenshot (27).png', 1, 1, 1, 1, '2019-09-29 07:42:13'),
(16, 1, 1, 'Screenshot (1).png', 'Android  App & Game  Developer', 'Screenshot (2).png', 11, 11, 1, 1, '2019-09-29 07:42:56');

-- --------------------------------------------------------

--
-- Table structure for table `posttbl_img`
--

CREATE TABLE `posttbl_img` (
  `postid` int(11) NOT NULL DEFAULT '0',
  `categoryid` int(11) NOT NULL,
  `languageid` int(11) NOT NULL,
  `thumbnail_img` text NOT NULL,
  `title` varchar(255) NOT NULL,
  `postpath` text NOT NULL,
  `no_of_like` int(11) NOT NULL,
  `no_of_share` int(11) NOT NULL,
  `no_of_download` int(11) NOT NULL,
  `no_of_view` int(11) NOT NULL,
  `post_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`) VALUES
(2, 'Uttam Yadav', 'uttamyadav1371996@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categorytbl`
--
ALTER TABLE `categorytbl`
  ADD PRIMARY KEY (`categoryid`),
  ADD KEY `languageid` (`languageid`);

--
-- Indexes for table `languagetbl`
--
ALTER TABLE `languagetbl`
  ADD PRIMARY KEY (`languageid`);

--
-- Indexes for table `posttbl`
--
ALTER TABLE `posttbl`
  ADD PRIMARY KEY (`postid`),
  ADD KEY `languageid` (`languageid`),
  ADD KEY `categoryid` (`categoryid`);

--
-- Indexes for table `posttbl_img`
--
ALTER TABLE `posttbl_img`
  ADD PRIMARY KEY (`postid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categorytbl`
--
ALTER TABLE `categorytbl`
  MODIFY `categoryid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `languagetbl`
--
ALTER TABLE `languagetbl`
  MODIFY `languageid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `posttbl`
--
ALTER TABLE `posttbl`
  MODIFY `postid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `categorytbl`
--
ALTER TABLE `categorytbl`
  ADD CONSTRAINT `categorytbl_ibfk_1` FOREIGN KEY (`languageid`) REFERENCES `languagetbl` (`languageid`);

--
-- Constraints for table `posttbl`
--
ALTER TABLE `posttbl`
  ADD CONSTRAINT `posttbl_ibfk_1` FOREIGN KEY (`languageid`) REFERENCES `languagetbl` (`languageid`),
  ADD CONSTRAINT `posttbl_ibfk_2` FOREIGN KEY (`categoryid`) REFERENCES `categorytbl` (`categoryid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
