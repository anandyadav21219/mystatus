<?php
				include "includes/header.php";
				?>

				<a class="btn btn-primary" href="edit-categorytbl.php?act=add"> <i class="glyphicon glyphicon-plus-sign"></i> Add New Category</a>

				<h1>Category</h1>
				<p>This table includes <?php echo counting("categorytbl", "id");?> Category.</p>

				<table id="sorted" class="table table-striped table-bordered">
				<thead>
				<tr>
					<th>Category</th>
					<th>Language</th>
					<th>Category-Name</th>
					<th>Category Image</th>
					<th class="not">Edit</th>
					<th class="not">Delete</th>
				</tr>
				</thead>

				<?php
				$categorytbl = getPost();
				if($categorytbl) foreach ($categorytbl as $categorytbls):
					?>
					<tr>
		<td><?php echo $categorytbls['categoryid']?></td>
		<td><?php echo $categorytbls['languagename']?></td>
		<td><?php echo $categorytbls['categoryname']?></td>
		<td><?php echo $categorytbls['category_img']?></td>


<td><a href="edit-categorytbl.php?act=edit&id=<?php echo $categorytbls['categoryid']?>"><i class="glyphicon glyphicon-edit"></i></a></td>
<td><a href="save.php?act=delete&id=<?php echo $categorytbls['categoryid'];?>&cat=categorytbl" onclick="return navConfirm(this.href);"><i class="glyphicon glyphicon-trash"></i></a></td>
						</tr>
					<?php endforeach; ?>
					</table>
					<?php include "includes/footer.php";?>
				
