<?php
include("includes/connect.php");
$cat = $_POST['cat'];
$cat_get = $_GET['cat'];
$act = $_POST['act'];
$act_get = $_GET['act'];
$id = $_POST['id'];
$id_get = $_GET['id'];



if ($cat == "admintbl" || $cat_get == "admintbl") {
	$adminid = mysqli_real_escape_string($link, $_POST["adminid"]);
	$adminpass = mysqli_real_escape_string($link, $_POST["adminpass"]);


	if ($act == "add") {
		mysqli_query($link, "INSERT INTO `admintbl` (  `adminid` , `adminpass` ) VALUES ( NULL, '" . $adminpass . "' ) ");
	} elseif ($act == "edit") {
		mysqli_query($link, "UPDATE `admintbl` SET  `adminid` =  '" . $adminid . "' , `adminpass` =  '" . $adminpass . "'  WHERE `id` = '" . $id . "' ");
	} elseif ($act_get == "delete") {
		mysqli_query($link, "DELETE FROM `admintbl` WHERE id = '" . $id_get . "' ");
	}
	header("location:" . "admintbl.php");
}

if ($cat == "categorytbl" || $cat_get == "categorytbl") {
	//echo "category insert";
	$categoryid = mysqli_real_escape_string($link, $_POST["categoryid"]);
	$languageid = mysqli_real_escape_string($link, $_POST["languageid"]);
	$categoryname = mysqli_real_escape_string($link, $_POST["categoryname"]);
	$catimg = mysqli_real_escape_string($link, $_FILES['categoryimg']['name']);

	// if ($act == "add") {
	// 	$tempcat = "INSERT INTO `categorytbl` (  `categoryid` , `languageid` , `categoryname`,`category_img` ) VALUES ( NULL, '" . $languageid . "' , '" . $categoryname . "','" . $catimg . "') ";
	// 	//echo $tempcat;
	// 	mysqli_query($link, $tempcat);
	if ($act == "add") {

		// File upload path
		$targetDir = "./uploads/categoryimg/";
		$fileName = basename($catimg);
		$currentDateTime = date(time());
		$targetFilePath = $targetDir . $currentDateTime . $fileName;
		$fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);
		if (!empty($catimg)) {
			// Upload file to server
			echo $targetFilePath . "<br />";
			echo $_FILES["categoryimg"]["tmp_name"];
			if (move_uploaded_file($_FILES["categoryimg"]["tmp_name"], $targetFilePath)) {
				$tempcat = "INSERT INTO `categorytbl` (  `categoryid` , `languageid` , `categoryname`,`category_img` ) VALUES ( NULL, '" . $languageid . "' , '" . $categoryname . "','" . $targetFilePath . "') ";
mysqli_query($link,$tempcat);
			} else {
				$statusMsg = "Sorry, there was an error uploading your file.";
			}
		} else {
			$statusMsg = 'Please select a file to upload.';
		}
	} elseif ($act == "edit") {
		mysqli_query($link, "UPDATE `categorytbl` SET  `languageid` =  '" . $languageid . "' , `categoryname` =  '" . $categoryname . "'  WHERE `categoryid` = '" . $id . "' ");
	} elseif ($act_get == "delete") {
		mysqli_query($link, "DELETE FROM `categorytbl` WHERE categoryid = '" . $id_get . "' ");
	}
	header("location:" . "categorytbl.php");
}



if ($cat == "languagetbl" || $cat_get == "languagetbl") {

	///					$languageid = mysqli_real_escape_string($link,$_POST["languageid"]);
	$languagename = mysqli_real_escape_string($link, $_POST["languagename"]);
	$languageimg = mysqli_real_escape_string($link, $_FILES['languageimg']['name']);

	if ($act == "add") {
		// File upload path
		$targetDir = "./uploads/languageimg/";
		$fileName = basename($languageimg);
		$currentDateTime = date(time());
		$targetFilePath = $targetDir . $currentDateTime . $fileName;
		$fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);
		if (!empty($languageimg)) {
			// Upload file to server
			echo $_FILES["languageimg"]["tmp_name"];
			if (move_uploaded_file($_FILES["languageimg"]["tmp_name"], $targetFilePath)) {
				mysqli_query($link, "INSERT INTO `languagetbl` (`languagename`,`Language_img` ) VALUES ('" . $languagename . "','" . $targetFilePath . "' ) ");
			} else {
				$statusMsg = "Sorry, there was an error uploading your file.";
			}
		} else {
			$statusMsg = 'Please select a file to upload.';
		}
	} elseif ($act == "edit") {
		mysqli_query($link, "UPDATE `languagetbl` SET  `languageid` =  '" . $languageid . "' , `languagename` =  '" . $languagename . "'  WHERE `id` = '" . $id . "' ");
	} elseif ($act_get == "delete") {
		mysqli_query($link, "DELETE FROM `languagetbl` WHERE languageid = '" . $id_get . "' ");
	}
	header("location:" . "languagetbl.php");
}

if ($cat == "posttbl" || $cat_get == "posttbl") {

	$categoryid = mysqli_real_escape_string($link, $_POST["categoryid"]);
	$languageid = mysqli_real_escape_string($link, $_POST["languageid"]);
	$title = mysqli_real_escape_string($link, $_POST["title"]);

	$no_of_like = mysqli_real_escape_string($link, $_POST["no_of_like"]);
	$no_of_share = mysqli_real_escape_string($link, $_POST["no_of_share"]);
	$no_of_download = mysqli_real_escape_string($link, $_POST["no_of_download"]);
	$no_of_view = mysqli_real_escape_string($link, $_POST["no_of_view"]);

	$thumb = mysqli_real_escape_string($link, $_FILES['thumb']['name']);
	$postpath = mysqli_real_escape_string($link, $_FILES['postpath']['name']);

	$currentDateTime =  date(time());
	
	$post_date = mysqli_real_escape_string($link, $currentDateTime);



	if ($act == "add") {
		if (!empty($_FILES["postpath"]["name"])) {

			$targetDir1 = "./uploads/Videos/";
			$fileName1 = basename($thumb);
			$targetFilePath1 = $targetDir1 . $currentDateTime . $fileName1;
			$fileType1 = pathinfo($targetFilePath1, PATHINFO_EXTENSION);


			// Upload file to server
			if (move_uploaded_file($_FILES["thumb"]["tmp_name"], $targetFilePath1)) { }
		}
		// File upload path
		$targetDir = "./uploads/Videos/";
		$fileName = basename($postpath);
		$targetFilePath = $targetDir . $currentDateTime . $fileName;
		$fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

		

		if (!empty($_FILES["postpath"]["name"])) {

			// Upload file to server
			if (move_uploaded_file($_FILES["postpath"]["tmp_name"], $targetFilePath)) {
				mysqli_query($link, "INSERT INTO `posttbl` (`categoryid` , `languageid` ,`thumbnail_img`, `title` , `postpath` , `no_of_like` , `no_of_share` , `no_of_download` , `no_of_view` , `post_date` ) VALUES ('" . $categoryid . "' , '" . $languageid . "','" . $targetFilePath1 . "'  , '" . $title . "' , '" . $targetFilePath . "' , '" . $no_of_like . "' , '" . $no_of_share . "' , '" . $no_of_download . "' , '" . $no_of_view . "' , '" . $post_date . "' ) ");
				
			} else {
				$statusMsg = "Sorry, there was an error uploading your file.";
			}
		} else {
			$statusMsg = 'Please select a file to upload.';
		}
	} elseif ($act == "edit") {
		mysqli_query($link, "UPDATE `posttbl` SET  `postid` =  '" . $postid . "' , `categoryid` =  '" . $categoryid . "' , `languageid` =  '" . $languageid . "' , `title` =  '" . $title . "' , `postpath` =  '" . $postpath . "' , `no_of_like` =  '" . $no_of_like . "' , `no_of_share` =  '" . $no_of_share . "' , `no_of_download` =  '" . $no_of_download . "' , `no_of_view` =  '" . $no_of_view . "' , `post_date` =  '" . $post_date . "'  WHERE `id` = '" . $id . "' ");
	} elseif ($act_get == "delete") {
		mysqli_query($link, "DELETE FROM `posttbl` WHERE postid = '" . $id_get . "' ");
	}
	header("location:" . "posttbl.php");
}

if ($cat == "users" || $cat_get == "users") {

	$name = mysqli_real_escape_string($link, $_POST["name"]);
	$email = mysqli_real_escape_string($link, $_POST["email"]);
	$password = mysqli_real_escape_string($link, $_POST["password"]);
	$role = mysqli_real_escape_string($link, $_POST["role"]);


	if ($act == "add") {
		mysqli_query($link, "INSERT INTO `users` (  `name` , `email` , `password` , `role` ) VALUES ( '" . $name . "' , '" . $email . "' , '" . md5($password) . "', '" . $role . "' ) ");
	} elseif ($act == "edit") {
		mysqli_query($link, "UPDATE `users` SET  `name` =  '" . $name . "' , `email` =  '" . $email . "' , `role` =  '" . $role . "'  WHERE `id` = '" . $id . "' ");
	} elseif ($act_get == "delete") {
		mysqli_query($link, "DELETE FROM `users` WHERE id = '" . $id_get . "' ");
	}
	header("location:" . "users.php");
}

//Post Image


if ($cat == "posttbl_img" || $cat_get == "posttbl_img") {

	$categoryid = mysqli_real_escape_string($link, $_POST["categoryid"]);
	$languageid = mysqli_real_escape_string($link, $_POST["languageid"]);
	$title = mysqli_real_escape_string($link, $_POST["title"]);

	$no_of_like = mysqli_real_escape_string($link, $_POST["no_of_like"]);
	$no_of_share = mysqli_real_escape_string($link, $_POST["no_of_share"]);
	$no_of_download = mysqli_real_escape_string($link, $_POST["no_of_download"]);
	$no_of_view = mysqli_real_escape_string($link, $_POST["no_of_view"]);

	$thumb = mysqli_real_escape_string($link, $_FILES['thumb']['name']);
	$postpath = mysqli_real_escape_string($link, $_FILES['postpath']['name']);

	$currentDateTime = date(time());
	$post_date = mysqli_real_escape_string($link, $currentDateTime);



	if ($act == "add") {
		if (!empty($_FILES["postpath"]["name"])) {

			$targetDir1 = "./uploads/Images/";
			$fileName1 = basename($thumb);
			$targetFilePath1 = $targetDir1 . $currentDateTime . $fileName1;
			$fileType1 = pathinfo($targetFilePath1, PATHINFO_EXTENSION);


			// Upload file to server
			if (move_uploaded_file($_FILES["thumb"]["tmp_name"], $targetFilePath1)) { }
		}
		// File upload path
		$targetDir = "./uploads/Images/";
		$fileName = basename($postpath);
		$targetFilePath = $targetDir . $fileName;
		$fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

		if (!empty($_FILES["postpath"]["name"])) {
                      echo "a"  ;
			// Upload file to server
			if (move_uploaded_file($_FILES["postpath"]["tmp_name"], $targetFilePath)) {
                   echo "b";
				mysqli_query($link, "INSERT INTO `posttbl_img` (`categoryid` , `languageid` ,`thumbnail_img`, `title` , `postpath` , `no_of_like` , `no_of_share` , `no_of_download` , `no_of_view` , `post_date` ) VALUES ('" . $categoryid . "' , '" . $languageid . "','" . $targetFilePath1 . "'  , '" . $title . "' , '" . $targetFilePath . "' , '" . $no_of_like . "' , '" . $no_of_share . "' , '" . $no_of_download . "' , '" . $no_of_view . "' , '" . $post_date . "' ) ");
				//echo "INSERT INTO `posttbl_img` (`categoryid` , `languageid` ,`thumbnail_img`, `title` , `postpath` , `no_of_like` , `no_of_share` , `no_of_download` , `no_of_view` , `post_date` ) VALUES ('" . $categoryid . "' , '" . $languageid . "','" . $thumb . "'  , '" . $title . "' , '" . $targetFilePath . "' , '" . $no_of_like . "' , '" . $no_of_share . "' , '" . $no_of_download . "' , '" . $no_of_view . "' , '" . $post_date . "' ) ";
			} else {
				$statusMsg = "Sorry, there was an error uploading your file.";
			}
		} else {
			$statusMsg = 'Please select a file to upload.';
		}
	} elseif ($act == "edit") {
		mysqli_query($link, "UPDATE `posttbl_img` SET  `categoryid` =  '" . $categoryid . "' , `languageid` =  '" . $languageid . "' , `title` =  '" . $title . "'   WHERE `postid` = '" . $id . "' ");
	} elseif ($act_get == "delete") {
		mysqli_query($link, "DELETE FROM `posttbl_img` WHERE postid = '" . $id_get . "' ");
	}
	header("location:" . "posttbl_img.php");
}

?>
