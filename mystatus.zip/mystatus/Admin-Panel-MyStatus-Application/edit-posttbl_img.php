<?php
				include "includes/header.php";
				$data=[];

				$act = $_GET['act'];
				if($act == "edit"){
					$id = $_GET['id'];
					$posttbl = getById("posttbl_img", $id);
				}
				?>

				<form method="post" action="save.php" enctype='multipart/form-data'>
					<fieldset>
						<legend class="hidden-first">Add New Posttbl</legend>
						<input name="cat" type="hidden" value="posttbl_img">
						<input name="id" type="hidden" value="<?=$id?>">
						<input name="act" type="hidden" value="<?=$act?>">

						<label>Select-Language</label>
							<?php
							$query = "SELECT * FROM languagetbl ";
							$result = qSELECT($query);
							?>
							<select name="languageid" class="form-control">
							<?php
							foreach ($result as $row){
								?>
									<option value="<?=$row['languageid']?>" ><?php echo $row['languagename']; ?></option>
								<?php
							}
							?>
							</select><br>

							<label>Select-Category</label>
							<?php
							$query = "SELECT * FROM categorytbl ";
							$result = qSELECT($query);
							?>
							<select name="categoryid" class="form-control">
							<?php
							foreach ($result as $row){
								?>
									<option value="<?=$row['categoryid']?>" ><?php echo $row['categoryname']; ?></option>
								<?php
							}
							?>
							</select><br>

							<label>Tumbnail Image</label>
							<input class="form-control" type="file" name="thumb" value="<?=$posttbl['thumb']?>" /><br>
							
							<label>Title</label>
							<input class="form-control" type="text" name="title" value="<?=$posttbl['title']?>" /><br>
							
							<label>Browse Video/Image</label>
							<input class="form-control" type="file" name="postpath" value="<?=$posttbl['postpath']?>" /><br>
							
							<label>No of like</label>
							<input class="form-control" type="text" name="no_of_like" value="<?=$posttbl['no_of_like']?>" /><br>
							
							<label>No of share</label>
							<input class="form-control" type="text" name="no_of_share" value="<?=$posttbl['no_of_share']?>" /><br>
							
							<label>No of download</label>
							<input class="form-control" type="text" name="no_of_download" value="<?=$posttbl['no_of_download']?>" /><br>
							
							<label>No of view</label>
							<input class="form-control" type="text" name="no_of_view" value="<?=$posttbl['no_of_view']?>" /><br>
							
					<input type="submit" value=" Save " class="btn btn-success">
					</form>
					<?php include "includes/footer.php";?>
				