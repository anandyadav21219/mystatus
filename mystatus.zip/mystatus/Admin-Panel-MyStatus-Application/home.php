<?php
		include "includes/header.php";
		?>
		<table class="table table-striped">
		<tr>
		<th class="not">Table</th>
		<th class="not">Entries</th>
		</tr>
					
				<tr>
					<td><a href="categorytbl.php">Category</a></td>
					<td><?=counting("categorytbl", "id")?></td>
				</tr>
				
				<tr>
					<td><a href="languagetbl.php">Language</a></td>
					<td><?=counting("languagetbl", "id")?></td>
				</tr>
				
				<tr>
					<td><a href="posttbl.php">Post-Video</a></td>
					<td><?=counting("posttbl", "id")?></td>
				</tr>
				<tr>
					<td><a href="posttbl_img.php">Post-Image</a></td>
					<td><?=counting("posttbl_img", "id")?></td>
				</tr>
				
				<tr>
					<td><a href="users.php">Users</a></td>
					<td><?=counting("users", "id")?></td>
				</tr>
				</table>
			<?php include "includes/footer.php";?>
			